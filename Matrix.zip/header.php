<header>
    <div class="belt">
        <a href="index.php">
            <img id="logo" src="images/shitty%20logo.png" alt="logo"/>
            <div id="logoText">
                Matrix Translator
                <div id="logoSubTitle">making matrices a little less shitty</div>
            </div>
        </a>


        <ul>
            <li><a href="index.php">Matrix</a></li>
            <li><a href="about.php">About</a></li>
        </ul>
        <div style="clear:both"></div>
    </div>
</header>