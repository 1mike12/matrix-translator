<footer id="footer" class="dropShadow">
    <div id="footerPadding">
        <span>copyright Mike Qin and Brian Gioia</span>
    </div>
</footer>