<head>
    <link rel="stylesheet" href="css/style.css" />
    <link rel="stylesheet" href="css/about.css" />
    <link rel="stylesheet" href="css/matrix.css" />
    <link rel="stylesheet" href="css/responsive.css" />


    <script src="scripts/jquery-1.9.1.js"></script>
    <script src="scripts/script.js"></script>
    
    <!--qtip2 shit-->
    <link rel="stylesheet" href="scripts/jquery.qtip.css" />
    <script src="scripts/jquery.qtip.js"></script>
    
    <meta charset="UTF-8">
    <title></title>
</head>