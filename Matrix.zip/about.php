<!DOCTYPE html>
<html>
    <?php include 'head.php'?>
    <body>
        <?php include 'header.php'?>
        <div id="wrapper">
            <div class="section group">
                <div class="col span_3_of_3">
                    <div id="banner">
                        <span class="h-Center">About Matrix Translator</span>
                    </div>
                    <div class="content">
                        <h1 style="margin:auto; display:block; width:50%;">content</h1>
                    </div>
                </div>
            </div>
        </div>
        <?php include 'footer.php'?>
    </body>
</html>
